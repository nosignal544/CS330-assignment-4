import java.util.Arrays;
import java.util.Scanner;
public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		String key = "";
		key = input.nextLine();
		key = key.replaceAll(" ","");
		int length = key.length();
		char[] word = new char[length];
		char[] sortedWord = new char[length];
		for(int i = 0; i < word.length; i++) {
			word[i] = key.charAt(i);
			sortedWord[i] = key.charAt(i);
		}
		Arrays.sort(sortedWord);
		for(int i = 0; i <word.length; i++) {
			System.out.printf("%-3s",word[i]);
			
		}
		System.out.println();
		for(int i = 0; i <word.length; i++) {
			System.out.printf("%-3s",sortedWord[i]);
		}
		String ciphertext = "Dehevsgbieltnrwplerettersttalnihtteindehevsghftmhuuetaoeiytrrteasdelfyoiuotoiharbdtruugofialtcnfsf";

		System.out.println("\n" + ciphertext);
		for(int i = 0; i < ciphertext.length(); i ++) {
			System.out.print(ciphertext.charAt(i));
			if(i%5 == 0 && i!= 0 && i !=ciphertext.length()) {
				System.out.print(" ");
			}
		}
		String ciphertext2 = "eshoyuelhttilireafrnasyuogtneedsdpifroaveeusrnstiudbfttviigbedtltfhetmehtrlgtofltewouerthaacwnhrti";

		System.out.println("\n" + ciphertext2);
		for(int i = 0; i < ciphertext2.length(); i ++) {
			System.out.print(ciphertext2.charAt(i));
			if(i%5 == 0 && i!= 0 && i !=ciphertext2.length()) {
				System.out.print(" ");
			}
		}

		

	}

}
